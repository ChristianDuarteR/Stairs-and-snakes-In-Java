package domain;
public interface Item {

	default void DoAction(Ficha ficha) throws StairsAndSnakesException {

	}

	default void SetObject(){

	}

}
